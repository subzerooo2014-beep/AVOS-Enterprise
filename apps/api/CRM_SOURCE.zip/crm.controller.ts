﻿import { Body, Controller, Delete, Get, Param, Patch, Post, Query } from "@nestjs/common";
import { CrmService } from "./crm.service";
import { CreateCrmDto } from "./dto/create-crm.dto";
import { UpdateCrmDto } from "./dto/update-crm.dto";

@Controller("crm")
export class CrmController {
  constructor(private readonly service: CrmService) {}

  @Get()
  findAll(@Query() query: any) {
    return this.service.findAll(query);
  }

  @Get("dashboard")
  dashboard() {
    return this.service.dashboard();
  }

  @Get("pipeline")
  pipeline() {
    return this.service.pipeline();
  }

  @Get(":id/customer-360")
  customer360(@Param("id") id: string) {
    return this.service.customer360(id);
  }

  @Get(":id")
  findOne(@Param("id") id: string) {
    return this.service.findOne(id);
  }

  @Post()
  create(@Body() dto: CreateCrmDto) {
    return this.service.create(dto);
  }

  @Patch(":id")
  update(@Param("id") id: string, @Body() dto: UpdateCrmDto) {
    return this.service.update(id, dto);
  }

  @Post(":id/status")
  changeStatus(@Param("id") id: string, @Body("status") status: string) {
    return this.service.changeStatus(id, status);
  }

  @Post(":id/assign")
  assign(@Param("id") id: string, @Body("assignedToId") assignedToId: string) {
    return this.service.assign(id, assignedToId);
  }

  @Post(":id/follow-up")
  scheduleFollowUp(@Param("id") id: string, @Body("nextFollowUpAt") nextFollowUpAt: string) {
    return this.service.scheduleFollowUp(id, nextFollowUpAt);
  }

  @Post(":id/activity")
  addActivity(@Param("id") id: string, @Body() dto: any) {
    return this.service.addActivity(id, dto);
  }

  @Delete(":id")
  remove(@Param("id") id: string) {
    return this.service.remove(id);
  }
}
