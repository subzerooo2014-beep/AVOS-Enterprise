﻿import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { CrmMapper } from "./mappers/crm.mapper";
import { CrmPolicy } from "./policies/crm.policy";
import { buildCrmWhere, normalizeCrmPaging } from "./helpers/crm-query.helper";
import { createCrmNumber } from "./helpers/crm-number.helper";
import { calculateCrmScore } from "./helpers/crm-score.helper";
import { createCrmTimelineEvent, appendCrmTimeline } from "./helpers/crm-timeline.helper";
import { createCrmActivity, appendCrmActivity } from "./helpers/crm-activity.helper";
import { groupCrmPipeline } from "./helpers/crm-pipeline.helper";
import { buildCustomer360 } from "./helpers/crm-customer360.helper";
import { calculateCrmPriority } from "./helpers/crm-priority.helper";

@Injectable()
export class CrmService {
  constructor(private readonly prisma: PrismaService) {}

  private delegate() {
    const client = this.prisma as any;

    if (!client.crm) {
      throw new BadRequestException("Prisma delegate 'crm' is not available.");
    }

    return client.crm;
  }

  private optionalDelegate(name: string): any {
    const client = this.prisma as any;
    return client?.[name] ?? null;
  }

  async findAll(query: any = {}) {
    const { page, limit, skip, take } = normalizeCrmPaging(query);
    const where = buildCrmWhere(query);

    const [items, total] = await Promise.all([
      this.delegate().findMany({
        where,
        skip,
        take,
        orderBy: { createdAt: "desc" },
      }),
      this.delegate().count({ where }),
    ]);

    return {
      items: items.map((item: any) => ({
        ...item,
        priority: calculateCrmPriority(item),
      })),
      meta: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    };
  }

  async findOne(id: string) {
    const record = await this.delegate().findUnique({ where: { id } });

    if (!record) {
      throw new NotFoundException("CRM record not found");
    }

    return {
      ...record,
      priority: calculateCrmPriority(record),
    };
  }

  async create(dto: any) {
    const data = CrmMapper.toCreate({
      ...dto,
      number: dto?.number ?? createCrmNumber(),
    });

    data.score = calculateCrmScore(data);
    data.timeline = [createCrmTimelineEvent("CREATED", data)];
    data.activities = [
      createCrmActivity("CREATED", "CRM record created", {
        status: data.status,
      }),
    ];

    return this.delegate().create({ data });
  }

  async update(id: string, dto: any) {
    const record = await this.delegate().findUnique({ where: { id } });
    CrmPolicy.ensureCanUpdate(record);

    const data = CrmMapper.toUpdate(dto);

    data.score = calculateCrmScore({
      ...record,
      ...data,
    });

    data.timeline = appendCrmTimeline(
      record,
      createCrmTimelineEvent("UPDATED", data),
    );

    data.activities = appendCrmActivity(
      record,
      createCrmActivity("UPDATED", "CRM record updated", data),
    );

    return this.delegate().update({
      where: { id },
      data,
    });
  }

  async dashboard() {
    const delegate = this.delegate();

    const [
      total,
      newCount,
      contacted,
      qualified,
      opportunity,
      won,
      lost,
      inactive,
    ] = await Promise.all([
      delegate.count(),
      delegate.count({ where: { status: "NEW" } }),
      delegate.count({ where: { status: "CONTACTED" } }),
      delegate.count({ where: { status: "QUALIFIED" } }),
      delegate.count({ where: { status: "OPPORTUNITY" } }),
      delegate.count({ where: { status: "WON" } }),
      delegate.count({ where: { status: "LOST" } }),
      delegate.count({ where: { status: "INACTIVE" } }),
    ]);

    const active = newCount + contacted + qualified + opportunity;

    return {
      total,
      newCount,
      contacted,
      qualified,
      opportunity,
      won,
      lost,
      inactive,
      active,
      winRate: total ? Number(((won / total) * 100).toFixed(2)) : 0,
      lossRate: total ? Number(((lost / total) * 100).toFixed(2)) : 0,
      conversionRate: total ? Number(((won / total) * 100).toFixed(2)) : 0,
      pipelineHealth: {
        active,
        final: won + lost + inactive,
        opportunityRatio: total ? Number(((opportunity / total) * 100).toFixed(2)) : 0,
      },
    };
  }

  async pipeline() {
    const items = await this.delegate().findMany({
      orderBy: { createdAt: "desc" },
      take: 500,
    });

    return groupCrmPipeline(items);
  }

  async changeStatus(id: string, status: string) {
    CrmPolicy.ensureValidStatus(status);

    const record = await this.delegate().findUnique({ where: { id } });
    CrmPolicy.ensureExists(record);

    const data: any = {
      status,
      score: calculateCrmScore({ ...record, status }),
      timeline: appendCrmTimeline(
        record,
        createCrmTimelineEvent("STATUS_CHANGED", {
          from: record.status,
          to: status,
        }),
      ),
      activities: appendCrmActivity(
        record,
        createCrmActivity("STATUS_CHANGED", "CRM status changed", {
          from: record.status,
          to: status,
        }),
      ),
    };

    return this.delegate().update({
      where: { id },
      data,
    });
  }

  async assign(id: string, assignedToId: string) {
    const record = await this.delegate().findUnique({ where: { id } });
    CrmPolicy.ensureExists(record);

    const data: any = {
      assignedToId,
      score: calculateCrmScore({ ...record, assignedToId }),
      timeline: appendCrmTimeline(
        record,
        createCrmTimelineEvent("ASSIGNED", { assignedToId }),
      ),
      activities: appendCrmActivity(
        record,
        createCrmActivity("ASSIGNED", "CRM record assigned", { assignedToId }),
      ),
    };

    return this.delegate().update({
      where: { id },
      data,
    });
  }

  async scheduleFollowUp(id: string, nextFollowUpAt: string) {
    const record = await this.delegate().findUnique({ where: { id } });
    CrmPolicy.ensureExists(record);

    const data: any = {
      nextFollowUpAt: new Date(nextFollowUpAt),
      timeline: appendCrmTimeline(
        record,
        createCrmTimelineEvent("FOLLOW_UP_SCHEDULED", { nextFollowUpAt }),
      ),
      activities: appendCrmActivity(
        record,
        createCrmActivity("FOLLOW_UP_SCHEDULED", "Follow-up scheduled", {
          nextFollowUpAt,
        }),
      ),
    };

    return this.delegate().update({
      where: { id },
      data,
    });
  }

  async addActivity(id: string, dto: any) {
    const record = await this.delegate().findUnique({ where: { id } });
    CrmPolicy.ensureExists(record);

    const activity = createCrmActivity(
      dto?.type ?? "NOTE",
      dto?.description ?? dto?.note ?? "CRM activity",
      dto ?? {},
    );

    return this.delegate().update({
      where: { id },
      data: {
        activities: appendCrmActivity(record, activity),
        timeline: appendCrmTimeline(record, createCrmTimelineEvent("ACTIVITY_ADDED", activity)),
      },
    });
  }

  async customer360(id: string) {
    const record = await this.delegate().findUnique({ where: { id } });
    CrmPolicy.ensureExists(record);

    const salesDelegate = this.optionalDelegate("sale");
    const vehicleDelegate = this.optionalDelegate("vehicle");
    const taskDelegate = this.optionalDelegate("task");

    const [sales, vehicles, tasks] = await Promise.all([
      salesDelegate?.findMany
        ? salesDelegate.findMany({
            where: {
              OR: [
                { customerId: (record as any).customerId ?? undefined },
                { customerEmail: (record as any).email ?? undefined },
                { customerPhone: (record as any).phone ?? undefined },
              ],
            },
            take: 50,
            orderBy: { createdAt: "desc" },
          })
        : [],
      vehicleDelegate?.findMany
        ? vehicleDelegate.findMany({
            where: {
              customerId: (record as any).customerId ?? undefined,
            },
            take: 50,
            orderBy: { createdAt: "desc" },
          })
        : [],
      taskDelegate?.findMany
        ? taskDelegate.findMany({
            where: {
              crmId: id,
            },
            take: 50,
            orderBy: { createdAt: "desc" },
          })
        : [],
    ]);

    return buildCustomer360(record, sales, vehicles, tasks);
  }

  async remove(id: string) {
    const record = await this.delegate().findUnique({ where: { id } });
    CrmPolicy.ensureCanDelete(record);

    return this.delegate().delete({
      where: { id },
    });
  }
}
